#!/bin/bash

# Blacc Diamond Agent - One-Click Digital Ocean Deployment
# Ubuntu 22.04 LTS Optimized

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# ASCII Art Banner
echo -e "${CYAN}"
echo "██████╗ ██╗      █████╗  ██████╗ ██████╗    ██████╗ ██╗ █████╗ ███╗   ███╗ ██████╗ ███╗   ██╗██████╗ "
echo "██╔══██╗██║     ██╔══██╗██╔════╝██╔════╝    ██╔══██╗██║██╔══██╗████╗ ████║██╔═══██╗████╗  ██║██╔══██╗"
echo "██████╔╝██║     ███████║██║     ██║         ██║  ██║██║███████║██╔████╔██║██║   ██║██╔██╗ ██║██║  ██║"
echo "██╔══██╗██║     ██╔══██║██║     ██║         ██║  ██║██║██╔══██║██║╚██╔╝██║██║   ██║██║╚██╗██║██║  ██║"
echo "██████╔╝███████╗██║  ██║╚██████╗╚██████╗    ██████╔╝██║██║  ██║██║ ╚═╝ ██║╚██████╔╝██║ ╚████║██████╔╝"
echo "╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝    ╚═════╝ ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚═════╝ "
echo -e "${NC}"
echo -e "${PURPLE}🌊 Digital Ocean Ubuntu Deployment${NC}"
echo -e "${BLUE}💎 One-Click AI Trading System Setup${NC}"
echo ""

echo -e "${YELLOW}🚀 Starting Blacc Diamond Agent deployment on Digital Ocean...${NC}"

# Update system
echo -e "${BLUE}📦 Updating Ubuntu system...${NC}"
sudo apt update && sudo apt upgrade -y

# Install essential packages
echo -e "${BLUE}🔧 Installing essential packages...${NC}"
sudo apt install -y curl wget git build-essential pkg-config libssl-dev \
    htop screen tmux nginx certbot python3-certbot-nginx \
    postgresql postgresql-contrib redis-server

# Install Rust
echo -e "${BLUE}🦀 Installing Rust...${NC}"
if ! command -v cargo &> /dev/null; then
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source ~/.cargo/env
    rustup default stable
    rustup update
fi

# Install Solana CLI
echo -e "${BLUE}☀️ Installing Solana CLI...${NC}"
if ! command -v solana &> /dev/null; then
    sh -c "$(curl -sSfL https://release.solana.com/v1.18.0/install)"
    export PATH="$HOME/.local/share/solana/install/active_release/bin:$PATH"
fi

# Create application directory
echo -e "${BLUE}📁 Setting up application directory...${NC}"
sudo mkdir -p /opt/blacc-diamond
sudo chown $USER:$USER /opt/blacc-diamond
cd /opt/blacc-diamond

# Copy source files
echo -e "${BLUE}📋 Copying application files...${NC}"
cp -r ~/digital_ocean_package/* .

# Set up environment
echo -e "${BLUE}⚙️ Configuring environment...${NC}"
cp .env.production .env

# Create necessary directories
mkdir -p logs data wallets backups config

# Build the application
echo -e "${BLUE}🔨 Building Blacc Diamond Agent...${NC}"
export RUSTFLAGS="-C target-cpu=native"
cargo build --release

# Generate wallets
echo -e "${BLUE}💰 Generating encrypted wallets...${NC}"
cargo run --release --bin wallet-generator -- --count 5

# Set up systemd service
echo -e "${BLUE}🔧 Setting up systemd service...${NC}"
sudo tee /etc/systemd/system/blacc-diamond.service > /dev/null << EOF
[Unit]
Description=Blacc Diamond Agent - AI Trading System
After=network.target postgresql.service redis.service

[Service]
Type=simple
User=$USER
WorkingDirectory=/opt/blacc-diamond
ExecStart=/opt/blacc-diamond/target/release/blacc-diamond-agent
Restart=always
RestartSec=10
Environment=RUST_LOG=info
Environment=RUST_BACKTRACE=1

[Install]
WantedBy=multi-user.target
EOF

# Set up nginx reverse proxy
echo -e "${BLUE}🌐 Configuring Nginx...${NC}"
sudo tee /etc/nginx/sites-available/blacc-diamond > /dev/null << EOF
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }

    location /metrics {
        proxy_pass http://127.0.0.1:9090;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
}
EOF

sudo ln -sf /etc/nginx/sites-available/blacc-diamond /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl restart nginx

# Set up firewall
echo -e "${BLUE}🔥 Configuring firewall...${NC}"
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw --force enable

# Set file permissions
echo -e "${BLUE}🔐 Setting secure permissions...${NC}"
chmod 600 .env
chmod 700 wallets/
chmod 600 wallets/* 2>/dev/null || true

# Enable and start services
echo -e "${BLUE}🚀 Starting services...${NC}"
sudo systemctl daemon-reload
sudo systemctl enable blacc-diamond
sudo systemctl start blacc-diamond
sudo systemctl enable nginx
sudo systemctl enable postgresql
sudo systemctl enable redis

# Display wallet addresses
echo -e "${GREEN}✅ Deployment complete!${NC}"
echo ""
echo -e "${CYAN}💰 Wallet Addresses (Fund these with SOL):${NC}"
for i in {1..5}; do
    if [ -f "wallets/wallet_${i}_dev.json" ]; then
        ADDRESS=$(cat "wallets/wallet_${i}_dev.json" | grep -o '"public_key":"[^"]*' | cut -d'"' -f4)
        echo -e "   Wallet ${i}: ${YELLOW}${ADDRESS}${NC}"
    fi
done

echo ""
echo -e "${CYAN}🎯 System Information:${NC}"
echo -e "   Dashboard: ${YELLOW}http://$(curl -s ifconfig.me)${NC}"
echo -e "   Status: ${YELLOW}sudo systemctl status blacc-diamond${NC}"
echo -e "   Logs: ${YELLOW}sudo journalctl -u blacc-diamond -f${NC}"
echo -e "   Restart: ${YELLOW}sudo systemctl restart blacc-diamond${NC}"

echo ""
echo -e "${CYAN}📋 Next Steps:${NC}"
echo -e "1. ${YELLOW}Fund wallets${NC} with SOL (minimum 0.1 SOL each)"
echo -e "2. ${YELLOW}Update API keys${NC} in /opt/blacc-diamond/.env"
echo -e "3. ${YELLOW}Restart service${NC}: sudo systemctl restart blacc-diamond"
echo -e "4. ${YELLOW}Monitor dashboard${NC} at your server IP"

echo ""
echo -e "${GREEN}🎉 Blacc Diamond Agent is now running on Digital Ocean!${NC}"
echo -e "${PURPLE}💎 Ready to revolutionize Solana trading!${NC}"

# Create quick commands script
cat > /opt/blacc-diamond/commands.sh << 'EOF'
#!/bin/bash
# Quick commands for Blacc Diamond management

case "$1" in
    "status")
        sudo systemctl status blacc-diamond
        ;;
    "logs")
        sudo journalctl -u blacc-diamond -f
        ;;
    "restart")
        sudo systemctl restart blacc-diamond
        echo "✅ Blacc Diamond restarted"
        ;;
    "stop")
        sudo systemctl stop blacc-diamond
        echo "🛑 Blacc Diamond stopped"
        ;;
    "start")
        sudo systemctl start blacc-diamond
        echo "🚀 Blacc Diamond started"
        ;;
    "wallets")
        echo "💰 Wallet Addresses:"
        for i in {1..5}; do
            if [ -f "wallets/wallet_${i}_dev.json" ]; then
                ADDRESS=$(cat "wallets/wallet_${i}_dev.json" | grep -o '"public_key":"[^"]*' | cut -d'"' -f4)
                echo "   Wallet ${i}: ${ADDRESS}"
            fi
        done
        ;;
    "dashboard")
        echo "📊 Dashboard: http://$(curl -s ifconfig.me)"
        ;;
    *)
        echo "Blacc Diamond Commands:"
        echo "  ./commands.sh status    - Check service status"
        echo "  ./commands.sh logs      - View live logs"
        echo "  ./commands.sh restart   - Restart service"
        echo "  ./commands.sh stop      - Stop service"
        echo "  ./commands.sh start     - Start service"
        echo "  ./commands.sh wallets   - Show wallet addresses"
        echo "  ./commands.sh dashboard - Show dashboard URL"
        ;;
esac
EOF

chmod +x /opt/blacc-diamond/commands.sh

echo -e "${BLUE}💡 Use ${YELLOW}./commands.sh${BLUE} for quick management commands${NC}"

