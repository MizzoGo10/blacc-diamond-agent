use std::env;
use tokio;
use tracing::{info, warn, error};
use anyhow::Result;
use std::sync::Arc;
use tokio::sync::Mutex;

mod ultimate_architect_agent;
mod dashboard_server;
mod console_interface;
mod file_upload_system;
mod api_integrations;

use ultimate_architect_agent::UltimateArchitectAgent;
use dashboard_server::DashboardServer;
use console_interface::ConsoleInterface;
use file_upload_system::FileUploadSystem;
use api_integrations::APIIntegrations;

#[tokio::main]
async fn main() -> Result<()> {
    // Initialize logging
    tracing_subscriber::fmt::init();
    
    // Load environment variables
    dotenv::dotenv().ok();
    
    info!("🤖 Starting Ultimate Architect Agent System");
    info!("🧠 Supreme AI Engineer for Blacc Diamond System");
    
    // Parse command line arguments
    let args: Vec<String> = env::args().collect();
    let mode = args.get(1).map(|s| s.as_str()).unwrap_or("full");
    
    match mode {
        "full" => run_full_system().await?,
        "architect" => run_architect_only().await?,
        "dashboard" => run_dashboard_only().await?,
        "console" => run_console_only().await?,
        "upload" => run_upload_system().await?,
        _ => {
            println!("🤖 Ultimate Architect Agent - Usage:");
            println!("  cargo run                # Full integrated system");
            println!("  cargo run architect      # Architect agent only");
            println!("  cargo run dashboard      # Dashboard server only");
            println!("  cargo run console        # Console interface only");
            println!("  cargo run upload         # File upload system only");
        }
    }
    
    Ok(())
}

async fn run_full_system() -> Result<()> {
    info!("🚀 Starting Complete Ultimate Architect System");
    
    // Initialize all components
    let mut architect = UltimateArchitectAgent::new();
    architect.initialize().await?;
    
    let dashboard = Arc::new(Mutex::new(DashboardServer::new()));
    let console = Arc::new(Mutex::new(ConsoleInterface::new()));
    let file_system = Arc::new(Mutex::new(FileUploadSystem::new()));
    let api_integrations = Arc::new(Mutex::new(APIIntegrations::new()));
    
    // Start dashboard server
    let dashboard_clone = dashboard.clone();
    let dashboard_handle = tokio::spawn(async move {
        let mut dash = dashboard_clone.lock().await;
        if let Err(e) = dash.start_server().await {
            error!("Dashboard server error: {}", e);
        }
    });
    
    // Start console interface
    let console_clone = console.clone();
    let console_handle = tokio::spawn(async move {
        let mut cons = console_clone.lock().await;
        if let Err(e) = cons.start_interface().await {
            error!("Console interface error: {}", e);
        }
    });
    
    // Start file upload system
    let file_clone = file_system.clone();
    let file_handle = tokio::spawn(async move {
        let mut fs = file_clone.lock().await;
        if let Err(e) = fs.start_upload_server().await {
            error!("File upload system error: {}", e);
        }
    });
    
    // Initialize API integrations
    {
        let mut apis = api_integrations.lock().await;
        apis.initialize().await?;
    }
    
    info!("✅ All systems online - Ultimate Architect ready!");
    info!("🌐 Dashboard: http://your-droplet-ip:8080");
    info!("💬 Console: http://your-droplet-ip:8081");
    info!("📁 File Upload: http://your-droplet-ip:8082");
    
    // Run the architect agent
    architect.run_supreme_architect().await?;
    
    // Wait for all services
    let _ = tokio::try_join!(dashboard_handle, console_handle, file_handle);
    
    Ok(())
}

async fn run_architect_only() -> Result<()> {
    info!("🤖 Starting Architect Agent Only");
    let mut architect = UltimateArchitectAgent::new();
    architect.initialize().await?;
    architect.run_supreme_architect().await?;
    Ok(())
}

async fn run_dashboard_only() -> Result<()> {
    info!("📊 Starting Dashboard Server Only");
    let mut dashboard = DashboardServer::new();
    dashboard.start_server().await?;
    Ok(())
}

async fn run_console_only() -> Result<()> {
    info!("💬 Starting Console Interface Only");
    let mut console = ConsoleInterface::new();
    console.start_interface().await?;
    Ok(())
}

async fn run_upload_system() -> Result<()> {
    info!("📁 Starting File Upload System Only");
    let mut file_system = FileUploadSystem::new();
    file_system.start_upload_server().await?;
    Ok(())
}

